// src/components/NavBar.jsx
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  AppBar,
  Toolbar,
  IconButton,
  Typography,
  Drawer,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Box
} from '@mui/material'
import MenuIcon         from '@mui/icons-material/Menu'
import HomeIcon         from '@mui/icons-material/Home'
import EventIcon        from '@mui/icons-material/Event'
import PharmacyIcon     from '@mui/icons-material/LocalPharmacy'
import RestaurantIcon   from '@mui/icons-material/Restaurant'
import PsychologyIcon   from '@mui/icons-material/Psychology'
import SpaIcon          from '@mui/icons-material/Spa'

const MENU_ITEMS = [
  { text: 'Dashboard',       icon: <HomeIcon />,      path: '/' },
  { text: 'Booking',         icon: <EventIcon />,     path: '/booking' },
  { text: 'E-Pharmacy',      icon: <PharmacyIcon />,  path: '/epharmacy' },
  { text: 'Dietetics',       icon: <RestaurantIcon />,path: '/dietetics' },
  { text: 'Mental Health',   icon: <PsychologyIcon />,path: '/mental-health' },
  { text: 'Herbal Medicine', icon: <SpaIcon />,       path: '/herbal' },
]

export default function NavBar() {
  const [open, setOpen] = useState(false)
  const navigate        = useNavigate()

  return (
    <>
      <AppBar position="static">
        <Toolbar>
          <IconButton
            edge="start"
            color="inherit"
            onClick={() => setOpen(true)}
            sx={{ mr: 2 }}
          >
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" component="div">
            FelanoCare
          </Typography>
        </Toolbar>
      </AppBar>

      <Drawer
        open={open}
        onClose={() => setOpen(false)}
      >
        <Box
          sx={{ width: 250 }}
          role="presentation"
          onClick={() => setOpen(false)}
          onKeyDown={() => setOpen(false)}
        >
          <List>
            {MENU_ITEMS.map(({ text, icon, path }) => (
              <ListItemButton
                key={text}
                onClick={() => navigate(path)}
              >
                <ListItemIcon>{icon}</ListItemIcon>
                <ListItemText primary={text} />
              </ListItemButton>
            ))}
          </List>
        </Box>
      </Drawer>
    </>
  )
}
