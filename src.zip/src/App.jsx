// src/App.jsx
import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { ThemeProvider } from '@mui/material/styles'
import { useAuth }      from './contexts/AuthContext'
import { useCart }      from './contexts/CartContext'
import { getAge, getAgeCategory } from './utils/age'

// Pages & Components
import Auth            from './components/Auth'
import ProfileForm     from './components/ProfileForm'
import MainDashboard   from './components/MainDashboard'
import BookingPage     from './pages/BookingPage'
import EPharmacyPage   from './pages/EPharmacyPage'
import DieteticsPage   from './pages/DieteticsPage'
import MentalHealthPage from './pages/MentalHealthPage'
import HerbalPage      from './pages/HerbalPage'
import NavBar          from './components/NavBar'

// MUI
import IconButton      from '@mui/material/IconButton'
import Badge           from '@mui/material/Badge'
import Button          from '@mui/material/Button'
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart'

// Your pre-defined themes
import { youthTheme, adultTheme, seniorTheme } from './themes'

export default function App() {
  const { user, userProfile, loading, logout } = useAuth()
  const { cartItems }                          = useCart()

  if (loading) return <p>Loading…</p>
  if (!user)    return <Auth />

  // ask for name + DOB if missing
  if (!userProfile?.name || !userProfile?.birthDate) {
    return <ProfileForm />
  }

  // pick the right theme by age
  const age      = getAge(userProfile.birthDate)
  const category = getAgeCategory(age)
  const themes   = { youth: youthTheme, adult: adultTheme, senior: seniorTheme }
  const theme    = themes[category]

  return (
    <ThemeProvider theme={theme}>
    <NavBar/>
      <header
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '1rem',
          backgroundColor: theme.palette.background.paper
        }}
      >
        <h1 style={{ margin: 0 }}>FelanoCare</h1>

        <div>
          {/* Cart Icon with Badge */}
          <IconButton
            onClick={() => { /* navigate to /epharmacy */ window.location.href = '/epharmacy' }}
            size="large"
            aria-label="show cart items"
            color="inherit"
          >
            <Badge badgeContent={cartItems.reduce((sum, i) => sum + i.quantity, 0)} color="secondary">
              <ShoppingCartIcon />
            </Badge>
          </IconButton>

          {/* Logout Button */}
          <Button
            onClick={logout}
            color="primary"
            variant="outlined"
            sx={{ ml: 2 }}
          >
            Log out
          </Button>
        </div>
      </header>

      <Routes>
        <Route path="/"            element={<MainDashboard ageCategory={category} />} />
        <Route path="/booking"     element={<BookingPage />} />
        <Route path="/epharmacy"   element={<EPharmacyPage />} />
        <Route path="/dietetics"   element={<DieteticsPage />} />
        <Route path="/mental-health" element={<MentalHealthPage />} />
        <Route path="/herbal"      element={<HerbalPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </ThemeProvider>
  )
}
